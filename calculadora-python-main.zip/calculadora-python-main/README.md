# Calculadora em Python
Uma calculadora simples de linha de comando feita em Python.
## Funcionalidades
- Adição
- Subtração
- Multiplicação
- Divisão (com verificação de divisão por zero)
## Como usar
Execute o script com Python:```bash python calculadora.py
